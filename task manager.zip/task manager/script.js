let task = []
function criteria(title, due_date, Status, Priority) {

    this.title = title;
    this.due_date = due_date;
    this.Status = Status;
    this.Priority = Priority;

}


function addStudent(btn) {
    const row = btn.closest("tr");
    const title = row.querySelector(".task").value;
    const date = row.querySelector(".date").value;
    const status = row.querySelector(".Status").value;
    const Priority = row.querySelector(".Priority").value;

    if (title === "" || date === "") {
        alert("Please fill task title and date");
        return;
    }

    let DataObj = new criteria(title, date, status, Priority)

    task.push(DataObj)
    renderSavedRow(row, DataObj);
    console.log(task)




}
function renderSavedRow(row, data) {
    row.dataset.index = task.length - 1;

    row.innerHTML = `
        <td>${task.length}</td>
        <td>${data.title}</td>
        <td>${data.due_date}</td>
        <td>${data.Status}</td>
        <td>${data.Priority}</td>
        <td>
            <button onclick="deleteRow(this)">Delete</button>
            <button onclick="doneRow(this)" class="done-btn">Done</button>
        </td>
    `;
}



let add = document.querySelector(".add-button")
add.addEventListener("click", addRow);


function addRow() {
    let row = document.createElement("tr")
    row.innerHTML = `<td>${a}</td>
                        <td><Input class="task" type="text" placeholder="task here"></Input></td>
                        <td><input class="date" type="date" placeholder="date"></td>
                        <td><select class="Status" name="Status" id="Status">
                                <option value="Done">Done</option>
                                <option value="In progress">In progress</option>
                                <option value="Not begin">Not begin</option>

                            </select></td>
                        <td><select class="Priority" name="Priority" id="Priority">
                                <option value="High">Done</option>
                                <option value="Moderate-High">Moderate-High</option>
                                <option value="Moderate">"Moderate"</option>
                                <option value="Moderate-Low">Moderate-Low</option>
                                <option value="Low">Low</option>

                            </select></td>
                        <td>
                            <button class="delete-btn">Delete</button>
                            
                            <button onclick="addStudent(this)" class="Create-btn">Create</button>
                            
                        </td>
    `
    let taskbody = document.querySelector("#task-body")
    taskbody.appendChild(row);
    a = a + 1;
}

function deleteRow(btn) {
    const row = btn.closest("tr");
    const index = row.dataset.index;

    task.splice(index, 1);
    row.remove();

    console.log(task);
}

function doneRow(btn) {
    const row = btn.closest("tr");

    row.classList.add("done");


    btn.disabled = true;
}



