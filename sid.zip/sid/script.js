let task = []
function criteria(title, due_date, Status, Priority) {

    this.title = title;
    this.due_date = due_date;
    this.Status = Status;
    this.Priority = Priority;

}


var CreateCondn = false;
function addStudent(btn) {
    const row = btn.closest("tr");
    const title = row.querySelector(".task").value;
    const date = row.querySelector(".date").value;
    const status = row.querySelector(".Status").value;
    const Priority = row.querySelector(".Priority").value;

    if (title === "" || date === "") {
        alert("Please fill task title and date");
        return;
    }

    let DataObj = new criteria(title, date, status, Priority)

    task.push(DataObj)
    renderSavedRow(row, DataObj);
    saveTasks();

    CreateCondn = true
    console.log(task)
    return true




}
function renderSavedRow(row, data) {
    row.dataset.index = task.length - 1;

    row.innerHTML = `
        <td></td>
        <td>${data.title}</td>
        <td>${data.due_date}</td>
        <td>${data.Status}</td>
        <td>${data.Priority}</td>
        <td>
            <spam class="edit">
            <button onclick="edit(this)" class="edit-button">Edit task</button>
            </spam>
            <button onclick="deleteRow(this)" class="delete-btn">Delete</button>
            <button onclick="doneRow(this)" class="done-btn">Done</button>
        </td>
    `;
    updateIndex();
}






function addRow() {
    let row = document.createElement("tr")
    let taskbody = document.querySelector("#task-body")
    taskbody.appendChild(row);
    row.innerHTML = `
                       <td></td>

                        <td><Input class="task" type="text" placeholder="task here"></Input></td>
                        <td><input class="date" type="date" placeholder="date"></td>
                        <td><select class="Status" name="Status" id="Status">
                                <option value="Done">Done</option>
                                <option value="In progress">In progress</option>
                                <option value="Not begin">Not begin</option>

                            </select></td>
                        <td><select class="Priority" name="Priority" id="Priority">
                                <option value="High">Done</option>
                                <option value="Moderate-High">Moderate-High</option>
                                <option value="Moderate">"Moderate"</option>
                                <option value="Moderate-Low">Moderate-Low</option>
                                <option value="Low">Low</option>

                            </select></td>
                        <td>
                        <spam class="edit">
                           
                            <button onclick="deleteRow(this)"  class="delete-btn">Delete</button>
                            <button onclick="doneRow(this)" class="done-btn">Done</button>
                            <button onclick="addStudent(this)" class="Create-btn">Create</button>
                            
                        </td>
                   
    `
    saveTasks()
}
function updateIndex() {
    const rows = document.querySelectorAll("#task-body tr")

    rows.forEach((Sno, i) => {
        Sno.dataset.index = i;
        Sno.children[0].textContent = i + 1;


    });

}

function deleteRow(btn) {
    const row = btn.closest("tr");
    const index = row.dataset.index;

    task.splice(index, 1);
    saveTasks();

    row.remove();
    updateIndex();

    console.log(task);
}

function doneRow(btn) {
    const row = btn.closest("tr");

    if (row.dataset.index === undefined) {
        alert("First create the task");
        return;
    }

    const index = row.dataset.index;


    task[index].Status = "Done";
    saveTasks();



    row.children[3].textContent = "Done";


    row.classList.add("done");
    btn.disabled = true;
    btn.hidden = true;

    console.log(task);
    updateIndex()
}

function filter(btn) {
    const rows = document.querySelectorAll("#task-body tr")
    rows.forEach(row => row.removeAttribute("hidden"));


    let but = document.querySelector("#filter")
    but.removeAttribute("hidden")
    if (but.value === "None") {
        return
    }

    else if (but.value === "show_Done") {
        const rows = document.querySelectorAll("#task-body tr")

        rows.forEach((status) => {
            if (status.children[3].textContent != "Done")

                status.setAttribute("hidden", true);


        });


    }
    else if (but.value === "show_InProgress") {
        const rows = document.querySelectorAll("#task-body tr")

        rows.forEach((status) => {
            if (status.children[3].textContent != "In progress")

                status.setAttribute("hidden", true);


        });


    }
    else if (but.value === "Show_NotBegin") {
        const rows = document.querySelectorAll("#task-body tr")

        rows.forEach((status) => {
            if (status.children[3].textContent != "Not begin")

                status.setAttribute("hidden", true);


        });


    }
    updateIndex()

}
function saveTasks() {
    localStorage.setItem("tasks", JSON.stringify(task))
}
function loadTasks() {
    let stored = localStorage.getItem("tasks");
    console.log(stored)
    if (stored) {
        task = JSON.parse(stored);

    }
}
function renderAllTasks() {
    const taskbody = document.querySelector("#task-body");
    taskbody.innerHTML = "";

    task.forEach((t, i) => {
        let row = document.createElement("tr");
        taskbody.appendChild(row);

        row.dataset.index = i;

        row.innerHTML = `
            <td></td>
            <td>${t.title}</td>
            <td>${t.due_date}</td>
            <td>${t.Status}</td>
            <td>${t.Priority}</td>
            <td>
                <button onclick="deleteRow(this)">Delete</button>
                <button onclick="doneRow(this)" class="done-btn">Done</button>
            </td>
        `;
    });

    updateIndex();
}
window.onload = function () {
    loadTasks();
    renderAllTasks();
};
function edit (btn) {
    const row = btn.closest("tr");
    row.innerHTML=`
                       <td></td>

                        <td><Input class="task" type="text" placeholder="task here"></Input></td>
                        <td><input class="date" type="date" placeholder="date"></td>
                        <td><select class="Status" name="Status" id="Status">
                                <option value="Done">Done</option>
                                <option value="In progress">In progress</option>
                                <option value="Not begin">Not begin</option>

                            </select></td>
                        <td><select class="Priority" name="Priority" id="Priority">
                                <option value="High">Done</option>
                                <option value="Moderate-High">Moderate-High</option>
                                <option value="Moderate">"Moderate"</option>
                                <option value="Moderate-Low">Moderate-Low</option>
                                <option value="Low">Low</option>

                            </select></td>
                        <td>
                        <spam class="edit">
                           
                            <button onclick="deleteRow(this)"  class="delete-btn">Delete</button>
                            <button onclick="doneRow(this)" class="done-btn">Done</button>
                            <button onclick="addStudent(this)" class="Create-btn">Create</button>
                            
                        </td>
                   
    `
    saveTasks();


}










